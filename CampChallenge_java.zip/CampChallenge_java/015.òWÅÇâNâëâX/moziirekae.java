/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author guest1Day
 */
public class moziirekae {
     public static void main(String[] args){
         String a=("きょUはぴIえIちぴIのくみこみかんすUのがくしゅUをしてIます");
         a=a.replace("I", "い");
         a=a.replace("U","う");
        
         System.out.print(a);
         //System.out.print(a.replace("U","う"));
         
     
     
     }
     
}
